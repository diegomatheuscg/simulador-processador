#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include "lib.h"
#include <bitset>
#include <iostream>

constexpr uint16_t mem_size = 1024 * 32;
uint16_t op0, op1, op2;

struct Mem {
	uint16_t memory[mem_size];
};

struct CPU {
	uint16_t registrador[8];
	uint16_t PC = 1;
};

// //extrai o tipo da instrução
int tipoInstrucao (uint16_t instrucao){
	uint16_t bitSignificativo = extract_bits(instrucao, 15, 1);
	return bitSignificativo;
}
// //Formato: 0 (tipo R)
// //• Opcode: 010000 (16 em decimal, load)
// //• Destino: ignoramos pois não é usado, usaremos 000 então
// //• Operando 1: 111 (7 em decimal)
// //• Operando 2: 010 (2 em decimal)
// //• Endereço de memória fica no Op1
// //• Valor a ser escrito fica no Op2
void executarInstrucao(uint16_t instrucao, CPU *cpu, Mem *mem) {
	uint16_t tipo = tipoInstrucao(instrucao);

	if (tipo == 0) {
		//extrai todos os operandos
		op0 = extract_bits(instrucao, 6, 3);
		op1 = extract_bits(instrucao, 3, 3);
		op2 = extract_bits(instrucao, 0, 3);
		//extrai o opcode e guarda na variavel
		uint16_t opcode = extract_bits(instrucao, 9, 6);
			switch(opcode) {
				case 0b000000: 
					cpu->registrador[op0]=cpu->registrador[op1]+cpu->registrador[op2];
					break;
				case 0b000001: 
					cpu->registrador[op0]=cpu->registrador[op1]-cpu->registrador[op2];
					break;
				case 0b000010: 
					cpu->registrador[op0]=cpu->registrador[op1]*cpu->registrador[op2];
					break;
				case 0b000011: 
					cpu->registrador[op0]=cpu->registrador[op1]/cpu->registrador[op2];
					break;
				case 0b001111:
					cpu->registrador[op0]=mem->memory[op1];//incorretos
					break;
				case 0b010000: 
					mem->memory[op0]=cpu->registrador[op1];//incorretos
					break;
				case 0b000100: 
					if(cpu->registrador[op1] == cpu->registrador[op2]){
						cpu->registrador[op0] = 0b0000000000000001;	
					} else {
						cpu->registrador[op0] = 0b0000000000000000;
					}
					break;
				case 0b000101: 
					if(cpu->registrador[op1] == cpu->registrador[op2]){
						cpu->registrador[op0] = 0b0000000000000000;	
					} else {
						cpu->registrador[op0] = 0b0000000000000001;
					}
					break;
				// case 0b000110: return "cmp_less";
				// case 0b000111: return "cmp_greater";
				// case 0b001000: return "cmp_less_eq";
				// case 0b001001: return "cmp_greater_eq";
				
				default: return "Instrução não executada.";
			}
		} else if(tipoInstrucao(instrucao) == 1){
		uint16_t opcode = extract_bits(instrucao, 13, 2);
			switch(opcode) {
				case 0b00: 
				uint16_t endereco_jump = 
				;
				case 0b01: return "jump_cond";
				case 0b11: return "mov";
				default: return "Instrução não executada.";
			}
		}
}



int main (int argc, char **argv)
{
	if (argc != 2) {
		printf("usage: %s [bin_name]\n", argv[0]);
		exit(1);
	}

	Mem mem;
	CPU cpu;

	load_binary_to_memory("teste.bin", mem.memory, mem_size);

	
	for(int i = 0; i < mem_size; i++){
		std::cout << std::bitset<16>(mem.memory[i]) << std::endl;
	}
	
	// while(1){
	// 	uint16_t instrucao = mem.memory[PC];//fetch
	// 	executarInstrucao(instrucao, mem, *cpu);//execute
	// 	PC++;//
	// }
	return 0;
}

//criar as estruturas do processador e da memória
//implementar decodificacao da instrucao
//implementar execucao da instrucao
//criar loop principal do processador


//se um operador ou número imediato é represntado no op por 3 bits, como que representaríamos um número maior
// como por exemplo 100, que teria mais do que 3 bits

//no .DATA não precisamos se preocupar com o tamanho dos

//é essencial definirmos antes de tudo importação das instruções binárias para nossa memória virtual *mem