#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include "lib.h"

constexpr uint16_t mem_size = 1024 * 64;
uint16_t op0, op1, op2;

struct Mem {
	uint16_t memory[mem_size];
};

struct CPU {
	uint16_t registrador[8];
	uint16_t PC;
};

//extrai o tipo da instrução
int tipoInstrucao (uint16_t instrucao){
	uint16_t bitSignificativo = extract_bits(instrucao, 15, 1);
	return bitSignificativo;
}
//Formato: 0 (tipo R)
//• Opcode: 010000 (16 em decimal, load)
//• Destino: ignoramos pois não é usado, usaremos 000 então
//• Operando 1: 111 (7 em decimal)
//• Operando 2: 010 (2 em decimal)
//• Endereço de memória fica no Op1
//• Valor a ser escrito fica no Op2
void executarInstrucao(uint16_t instrucao, CPU *cpu, Mem *mem, uint16_t ) {
	
	//extrai todos os operandos
	*op0 = extract_bits(instrucao, 8, 3);
	*op1 = extract_bits(instrucao, 5, 3);
	*op2 = extract_bits(instrucao, 2, 3);

	if (tipoInstrucao(instrucao) == 0) {
		//extrai o opcode e guarda na variavel
		uint16_t opcode = extract_bits(instrucao, 14, 6);
			switch(opcode) {
				case 0b000000: 
					cpu->registrador[op0]=cpu->registrador[op1]+cpu->registrador[op2];
					break;
				case 0b000001: 
					cpu->registrador[op0]=cpu->registrador[op1]-cpu->registrador[op2];
					break;
				case 0b000010: 
					cpu->registrador[op0]=cpu->registrador[op1]*cpu->registrador[op2];
					break;
				case 0b000011: 
					cpu->registrador[op0]=cpu->registrador[op1]/cpu->registrador[op2];
					break;
				case 0b001111:
				//load r7, [r2]
//• Formato: 0 (tipo R)
//• Opcode: 001111 (15 em decimal, load)
//• Destino: 111 (7 em decimal)
//• Operando 1: 010 (2 em decimal)
//• Operando 2: ignoramos pois não é usado, usaremos 000 então
//
//• Endereço de memória fica no Op1
					cpu->registrador[op0]=mem->memory[op1];
					break;
				case 0b010000: return "store";
				
				//case 0b000100: if();
				// case 0b000101: return "cmp_neq";
				// case 0b000110: return "cmp_less";
				// case 0b000111: return "cmp_greater";
				// case 0b001000: return "cmp_less_eq";
				// case 0b001001: return "cmp_greater_eq";
				
				default: return "Instrução não executada.";
			}
		} else if(tipoInstrucao(instrucao) == 1){
		uint16_t opcode = extract_bits(instrucao, 14, 2);
			switch(opcode) {
				case 0b00: 
				uint16_t endereco_jump = 
				;
				case 0b01: return "jump_cond";
				case 0b11: return "mov";
				default: return "Instrução não executada.";
			}
		}
}



int main (int argc, char **argv)
{
	if (argc != 2) {
		printf("usage: %s [bin_name]\n", argv[0]);
		exit(1);
	}

	Mem mem;
	CPU cpu;

	uint16_t instrucao = mem.memory[1];

	while(1){
		uint16_t instrucao = mem.memory[PC]//fetch
		executarInstrucao(instrucao, mem, cpu)//execute
		PC++;//
	}
	return 0;
}

//criar as estruturas do processador e da memória
//implementar decodificacao da instrucao
//implementar execucao da instrucao
//criar loop principal do processador


//se um operador ou número imediato é represntado no op por 3 bits, como que representaríamos um número maior
// como por exemplo 100, que teria mais do que 3 bits

//no .DATA não precisamos se preocupar com o tamanho dos

//é essencial definirmos antes de tudo importação das instruções binárias para nossa memória virtual *mem