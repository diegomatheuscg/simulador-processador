#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include "lib.h"

constexpr uint32_t mem_size = 1024 * 64;
const char* nomes_reg[] = {"r0", "r1", "r2", "r3", "r4", "r5", "r6", "r7"};
uint16_t op0, op1, op2;

struct Mem {
	uint32_t memory[mem_size];
};

struct CPU {
	uint16_t registrador[8];
	
	uint16_t PC;
};

int tipoInstrucao (uint16_t instrucao){
	uint8_t bitSignificativo = extract_bits(instrucao, 15, 1);
	return bitSignificativo;
}

void operandos(uint16_t instrucao, uint16_t* op0, uint16_t* op1, uint16_t* op2){

	uint16_t rd = extract_bits(instrucao, 8, 3);
	uint16_t rs = extract_bits(instrucao, 5, 3);
	uint16_t rt = extract_bits(instrucao, 2, 3);
	
	*op0 = rd;
	*op1 = rs;
	*op2 = rt;
}


const char* operadorInstrucao(uint16_t instrucao) {
	
	if (tipoInstrucao(instrucao) == 0) {
		uint8_t opcode = extract_bits(instrucao, 14, 6);
			switch(opcode) {
				case 0b000000: return "add";
				case 0b000001: return "sub";
				case 0b000010: return "mul";
				case 0b000011: return "div";
				case 0b000100: return "cmp_equal";
				case 0b000101: return "cmp_neq";
				case 0b000110: return "cmp_less";
				case 0b000111: return "cmp_greater";
				case 0b001000: return "cmp_less_eq";
				case 0b001001: return "cmp_greater_eq";
				case 0b001111: return "load";
				case 0b010000: return "store";
				default: return "Instrução não executada.";
			}
		} else if(tipoInstrucao(instrucao) == 1){
		uint8_t opcode = extract_bits(instrucao, 14, 2);
			switch(opcode) {
				case 0b00: return "jump";
				case 0b01: return "jump_cond";
				case 0b11: return "mov";
				default: return "Instrução não executada.";
			}
		}
}

void mostrar_instrucao(uint16_t instrucao, const char* nomes_reg[]){
	operandos(instrucao, &op0, &op1, &op2);
	printf("%s %s, %s, %s\n", operadorInstrucao(instrucao), nomes_reg[op0], nomes_reg[op1], nomes_reg[op2]);
}

int main (int argc, char **argv)
{
	
	if (argc != 2) {
		printf("usage: %s [bin_name]\n", argv[0]);
		exit(1);
	}


	
	
	Mem mem;
	CPU cpu;

	mem.memory[0] = 0b0000000100110111;
	mem.memory[1] = 0b1010000000000000;
	uint16_t instrucao = mem.memory[1];
	

	mostrar_instrucao(instrucao, nomes_reg);


	return 0;
}