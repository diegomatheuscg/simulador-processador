#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include "lib.h"
#include <bitset>
#include <iostream>

constexpr uint16_t mem_size = 1024 * 32;


struct Mem {
	uint16_t memory[mem_size];
};

int main (int argc, char **argv)
{
	if (argc != 2) {
		printf("usage: %s [bin_name]\n", argv[0]);
		exit(1);
	}

	Mem mem;

	load_binary_to_memory("teste.bin", mem.memory, mem_size);

	
	for(int i = 0; i < mem_size; i++){
		std::cout << std::bitset<16>(mem.memory[i]) << std::endl;
	}
	

	return 0;
}
