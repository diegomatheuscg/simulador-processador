#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include "lib.h"


constexpr uint16_t mem_size = 1024 * 64;
//R
uint16_t syscall = 0b111111;
uint16_t add = 0b000000;
uint16_t sub = 0b000001;
uint16_t mult = 0b000010;
uint16_t div = 0b000011;
uint16_t cmp_equal = 0b000100;
uint16_t cmp_neq = 0b000101;
uint16_t load = 0b001111;
uint16_t store = 0b010000;
//I
uint16_t jump = 0b00;
uint16_t jump_cond = 0b01;
uint16_t mov = 0b11;

struct Mem {
	uint16_t memory[mem_size];
};

struct CPU {
	uint16_t registrador[8];
	uint16_t pc;
};

void tipoInstrucao (uint16_t instrucao){
	//condição para saber se é instrução do tipo R ou tipo I
	//puxar a função do extract_bits lib.h
	//const uint16_t v, const uint8_t bstart, const uint8_t blength
	//endereçamento de memoria little end, da direita pra esquerda
	uint16_t bitSignificativo = extract_bits(instrucao, 15, 1);
	if(bitSignificativo == 1){
		
	}
}

int main (int argc, char **argv)
{

	if (argc != 2) {
		printf("usage: %s [bin_name]\n", argv[0]);
		exit(1);
	}

	Mem memory;
	memory.memory[0] = 0b0000000100110111;
	tipoInstrucao(memory[0]);

	return 0;
}